#!/bin/bash
#编译modem

curr_dir=`pwd`
cd ../
root_dir=`pwd`
echo "--------------"
echo $root_dir
echo "--------------"

#TOOLS_DIR=$root_dir/vendor/qcom/non-hlos/qcom_tools
#UTLILS_ROOT=${TOOLS_DIR}/rvct22
BP_PATH=$root_dir

#============ 环境配置 ================
export ARMLMD_LICENSE_FILE=$root_dir/qcom_tools/rvct22/license.dat
ARM_COMPILER_PATH=$root_dir/qcom_tools/rvct22/rvct22/linux-pentium
MAKE_PATH=/usr/bin
PYTHON_PATH=$root_dir/qcom_tools/python/2.7.5
export ARMTOOLS=RVCT221
export ARMROOT=$root_dir/qcom_tools/rvct22/rvct22
export ARMLIB=$ARMROOT/lib
export ARMINCLUDE=/$ARMROOT/include
export ARMINC=$ARMINCLUDE
export ARMCONF=$ARMROOT/linux-pentium
export ARMDLL=$ARMROOT/linux-pentium
export PATH=$MAKE_PATH:$PYTHON_PATH:$ARM_COMPILER_PATH:$PATH
export ARMHOME=$ARMROOT
export HEXAGON_ROOT=$root_dir/qcom_tools/Hexagon_Tools
echo $HEXAGON_ROOT
#============ 环境配置 ================
cd -

function build_mpss(){
    echo "========== build MPSS.AT.4.4 =========="
    local -r modem_path="MPSS.AT.4.4"
    if [ -d "$BP_PATH/$modem_path/modem_proc/build/ms" ]
    then
        cd "$BP_PATH/$modem_path/modem_proc/build/ms"
            ./build_variant.py sm6150.gen.prod - clean
            ./build_variant.py sm6150.gen.prod bparams=-k 
            [ "${PIPESTATUS[0]}" != "0" ] && echo -e "\033[31mbuild MPSS.AT.4.4 error\033[0m" && exit 1
        cd -
    else
        echo -e "\033[31m$AMSS_PATH/MPSS.AT.4.4/modem_proc/build/ms/: no such file or directory!!! \033[0m"
        exit 1
    fi
}

===========
build_mpss
