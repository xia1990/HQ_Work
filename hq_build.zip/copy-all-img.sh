#!/bin/bash

echo "========================= BEGIN TO COPY IMAGES ========================="
#platform
qcom_platform=$1
if [[ "${qcom_platform}" != "8917" && \
      "${qcom_platform}" != "8953" && \
      "${qcom_platform}" != "450"  && \
      "${qcom_platform}" != "632"  && \
      "${qcom_platform}" != "sdm439" ]]
then
    echo "Unsupported QCOM TARGET_FAMILY=$1"
    exit 1
else
    echo "QCOM TARGET_FAMILY=${qcom_platform}"
fi

#components
if [ "$2" = "all" ]; then
    echo "copy_all_img: HQ_BUILD_ARM_LICENSE=$HQ_BUILD_ARM_LICENSE"
    if [ "$HQ_BUILD_ARM_LICENSE" = "true" ]; then
        components="common adsp modem tz boot rpm"
    else
        components="common adsp modem tz"
    fi
else
    components="common "$2
fi

echo "copy components: $components"

#mkdir
CHIPCODE_DEST_DIR=$3
if [ "${CHIPCODE_DEST_DIR}" == "" ] ; 
then
    echo "Invalid CHIPCODE_DEST_DIR!"
    exit 1
fi

if [[ ! -e $CHIPCODE_DEST_DIR ]]; then
    mkdir -p $CHIPCODE_DEST_DIR
    if [ $? != 0 ]; then exit 1; fi
fi

echo "Destination dir: $CHIPCODE_DEST_DIR"

echo `pwd`

if [ "${qcom_platform}" = "sdm439" ]; then
common_files=(
$MSM_DEVICE_DIR/common/build/bin/asic/NON-HLOS.bin
$MSM_DEVICE_DIR/common/build/gpt_main0.bin
$MSM_DEVICE_DIR/common/build/gpt_backup0.bin
$MSM_DEVICE_DIR/common/sectools/resources/build/fileversion2/sec.dat
$MSM_DEVICE_DIR/common/config/partition.xml
$MSM_DEVICE_DIR/common/build/zeros_1sector.bin
$MSM_DEVICE_DIR/common/build/zeros_33sectors.bin
$MSM_DEVICE_DIR/common/build/rawprogram0_BLANK.xml
$MSM_DEVICE_DIR/common/build/rawprogram0.xml
$MSM_DEVICE_DIR/common/build/patch0.xml
)

modem_files=()

adsp_files=(
${QCT_ADSP_NAME}/adsp_proc/build/dynamic_signed/439/adspso.bin
)

boot_files=(
$QCT_BOOT_NAME/boot_images/build/ms/bin/FAASANAZ/sbl1.mbn
$QCT_BOOT_NAME/boot_images/build/ms/bin/FAADANAZ/prog_emmc_firehose_8937_ddr.mbn
)

rpm_files=(
$QCT_RPM_NAME/rpm_proc/build/ms/bin/439/rpm.mbn
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/tz.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/devcfg.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/km4.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/keymaster.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/keymaster64.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/cmnlib_30.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/cmnlib64_30.mbn
$QCT_TZ_NAME/trustzone_images/build/ms/bin/QAOAANAA/lksecapp.mbn
)

efuse_files=()

fi

#copy to des dir
for m in $components
do
    files=$m"_files[@]"
    for file in ${!files}
    do
        echo "Copy: $file"
        if [ -e $file ]; then
            cp  $file $CHIPCODE_DEST_DIR
        else
            echo "***FILE NO EXISTS*** $file"
        fi
    done
done
echo "========================= COPY IMAGES COMPLETE ========================="

