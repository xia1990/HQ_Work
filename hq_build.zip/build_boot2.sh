#!/bin/bash
#编译modem

curr_dir=`pwd`
cd ../../../../
root_dir=`pwd`


#"==================== 环境配置 =================="
export TOOLS_DIR=$root_dir/vendor/qcom/non-hlos/qcom_tools
export LM_LICENSE_FILE=8224@192.168.128.247:8224@192.168.132.222
export ARM_COMPILER_PATH=${TOOLS_DIR}/ARM_Compiler_5/bin64
export PYTHON_PATH=${TOOLS_DIR}/Python/Python-2.7.6
export MAKE_PATH=/usr/bin/make
export ARMTOOLS=ARMCT5.01
export ARMROOT=${TOOLS_DIR}/ARM_Compiler_5
export ARMLIB=$ARMROOT/lib
export ARMINCLUDE=$ARMROOT/include
export ARMINC=$ARMINCLUDE
export ARMBIN=$ARMROOT/bin64
export LLVMTOOLS=LLVM
export LLVMROOT=${TOOLS_DIR}/LLVM/4.0.2
export LLVMBIN=${TOOLS_DIR}/LLVM/4.0.2/bin
export LLVMLIB=$LLVMROOT/lib/clang/4.0.2/lib/linux
export LLVMINC=$MUSLPATH/include
export LLVM32INC=$MUSL32PATH/include
export LLVMTOOLPATH=$LLVMROOT/tools/bin
export PATH=$MAKE_PATH:$PYTHON_PATH:$ARM_COMPILER_PATH:$LLVMROOT:$PATH
export ARMHOME=$ARMROOT
export BP_PATH=$root_dir/vendor/qcom/non-hlos
#"==================== 环境配置 =================="


function build_boot(){
    echo "========== build BOOT.XF.3.1 =========="
    local -r boot_path="BOOT.XF.3.1"
    if [ -d "$BP_PATH/$boot_path/boot_images/QcomPkg/SDMPkg/6150" ]
    then
        cd "$BP_PATH/$boot_path/boot_images/QcomPkg/SDMPkg/6150"
            python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg,QcomToolsPkg -- build_flags=cleanall
            python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg, QcomToolsPkg
            [ "${PIPESTATUS[0]}" != "0" ] && echo -e "\033[31mbuild BOOT.XF.3.1 error\033[0m" && exit 1
        cd -
    else
        echo -e "\033[31m$BP_PATH/$boot_path/boot_images/QcomPkg/SDMPkg/6150: no such file or directory!!! \033[0m"
        exit 1
    fi
}

#================
build_boot
