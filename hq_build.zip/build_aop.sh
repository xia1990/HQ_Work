#!/bin/bash
#编译modem

curr_dir=`pwd`
cd ../../../../
root_dir=`pwd`
echo "--------------"
echo $root_dir
echo "--------------"
exit

export TOOLS_DIR=$root_dir/vendor/qcom/non-hlos/qcom_tools
BP_PATH=$root_dir
cd -

function build_aop(){
    echo "========== AOP.HO.2.0.3 =========="
    if [ -d "$BP_PATH/AOP.HO.2.0.3/aop_proc" ]
    then
    cd "$BP_PATH/AOP.HO.2.0.3/aop_proc/build"
        ./build_6150.sh -c
        ./build_6150.sh
        [ "${PIPESTATUS[0]}" != "0" ] && echo -e "\033[31mbuild AOP.HO.2.0.3 error\033[0m" && exit 1
    cd -
    else
        echo -e "\033[31m$BP_PATH/AOP.HO.2.0.3/: no such file or directory!!! \033[0m"
        exit 1
    fi
}

===========
build_aop
