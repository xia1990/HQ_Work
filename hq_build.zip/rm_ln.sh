#!/bin/bash

# this script should execute in vendor/qcom/non-hlos
LA_UM_NAME=$1

rm -rf build
rm -rf $LA_UM_NAME/LINUX/android
