#!/bin/bash

# this script should execute in vendor/qcom/non-hlos/hq_build
product_id=$1
build_mode=$2
parse_cfg=$3
if [ x$parse_cfg = x"" ]; then
    parse_cfg=true
fi

if [ "$build_mode" = "" ]; then
    build_mode=remake
fi

# init dirs
curr_dir=`pwd`
cd ../../../../
root_dir=`pwd`

# parse config
if [ $parse_cfg = "true" ]; then
    source $root_dir/build/make/hq_tools/parse_config.sh
    parse_config $root_dir $product_id
    if [ $? != 0 ]; then echo "*** failed to parse configs! *** "; exit 1; fi
fi

echo "==================== 环境配置 =================="
export TOOLS_DIR=$root_dir/vendor/qcom/$NON_HLOS_DIR/qcom_tools
cd $root_dir/vendor/qcom/$NON_HLOS_DIR/$QCT_TZ_NAME/trustzone_images/build/ms
export PYTHON_PATH=${TOOLS_DIR}/Python/Python-2.7.6
MAKE_PATH=/usr/bin/
export LLVMTOOLS=LLVM
export LLVMROOT=${TOOLS_DIR}/LLVM/4.0.11
export LLVMBIN=$LLVMROOT/bin
export LLVMLIB=$LLVMROOT/lib/clang/4.0.11/lib/linux
export MUSLPATH=$LLVMROOT/tools/lib64
export LLVMINC=$MUSLPATH/include
export LLVMTOOLPATH=$LLVMROOT/tools/bin
export CLANG=${TOOLS_DIR}/LLVM/4.0.11/bin/clang
echo "==================== 环境配置 =================="

if [[ "${QCOM_PLATFORM}" = "sm6150" ]]
then
    case $build_mode in
           new) python build_all.py -b TZ.XF.5.0 CHIPSET=sm6150 --config=bin/PAZAANAA/build_config_deploy.xml/build_config_deploy.xml -clean
                python build_all.py -b TZ.XF.5.0 CHIPSET=sm6150 --config=bin/PAZAANAA/build_config_deploy.xml/build_config_deploy.xml -recompile ;;

           remake) python build_all.py -b TZ.XF.5.0 CHIPSET=sm6150 --config=bin/PAZAANAA/build_config_deploy.xml/build_config_deploy.xml -recompile;;

           clean) python build_all.py -b TZ.XF.5.0 CHIPSET=sm6150 --config=bin/PAZAANAA/build_config_deploy.xml/build_config_deploy.xml -clean ;;
    esac
fi

tail -n 50 build-log.txt | grep "Build errors"
if [[ $? -eq 0 ]];then
    echo "==================== BUILD $QCT_TZ_NAME TZ FAIL =================="
    exit 1
else
    echo "==================== BUILD $QCT_TZ_NAME TZ COMPLETE =================="
fi

tail -n 50 LOGFILE.txt | grep "Build errors"
if [[ $? -eq 0 ]];then
    echo "==================== BUILD $QCT_TZ_NAME LOGFILE FAIL =================="
   exit 1
else
    echo "==================== BUILD $QCT_TZ_NAME LOGFILE COMPLETE =================="
fi
echo "==================== BUILD $QCT_TZ_NAME COMPLETE =================="
