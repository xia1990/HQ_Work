#!/bin/bash

# this script should execute in vendor/qcom/non-hlos
product_id=$1
mode=$2
parse_cfg=$3
if [ x$parse_cfg = x"" ]; then
    parse_cfg=true
fi

curr_dir=`pwd`
cd ../../../
root_dir=`pwd`

# parse config
if [ $parse_cfg = "true" ]; then
    source $root_dir/build/make/hq_tools/parse_config.sh
    parse_config $root_dir $product_id
    if [ $? != 0 ]; then echo "*** failed to parse config! *** "; exit 1; fi
fi

cd $curr_dir
echo "script=$0, start to split sparse"
./build_ln.sh $product_id no_parse_cfg

cd $MSM_DEVICE_DIR
case $QCOM_PLATFORM in
    660)
        rm -rf ./common/build/ufs/bin/asic/sparse_images/*
        rm -rf ./common/build/emmc/bin/asic/sparse_images/*
        ;;
    8917 | 8937 | 8953 | 632 | sdm439)
        rm -rf ./common/build/bin/aisc/sparse_images/*
        ;;
    *)
        echo "Error: Unsupported qcom platform=$platform!"
        exit 1
        ;;
esac

cd $curr_dir/$MSM_DEVICE_DIR/common/build
if [ x$mode = x"all" ]; then
    python build.py
else
    python build.py --$mode
fi

if [ $? -gt 0 ]; then
    cd $curr_dir
    ./rm_ln.sh
    exit 1
fi

cd $curr_dir
./rm_ln.sh $LA_UM_NAME

