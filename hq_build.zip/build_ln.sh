#!/bin/bash

# this script should execute in vendor/qcom/non-hlos
product_id=$1
parse_cfg=$2
if [ x$parse_cfg = x"" ]; then
    parse_cfg=true
fi

curr_dir=`pwd`
cd ../../../
root_dir=`pwd`

# parse config
if [ $parse_cfg = "true" ]; then
    source $root_dir/build/make/hq_tools/parse_config.sh
    parse_config $root_dir $product_id
    if [ $? != 0 ]; then echo "*** failed to parse config! *** "; exit 1; fi
fi

cd $curr_dir

rm -rf build
rm -f $LA_UM_NAME/LINUX/android/out
rm -f $LA_UM_NAME/LINUX/android/device
rm -rf $LA_UM_NAME/LINUX/android

mkdir build

ln -s ../$QCT_ADSP_NAME/adsp_proc build/adsp_proc
ln -s ../$QCT_BOOT_NAME/boot_images build/boot_images
ln -s ../$QCT_WCNSS_NAME/wcnss_proc build/wcnss_proc
ln -s ../$QCT_CPE_NAME/cpe_proc build/cpe_proc
ln -s ../$QCT_TZ_NAME/trustzone_images build/trustzone_images


mkdir -p $LA_UM_NAME/LINUX/android
ln -s ../$LA_UM_NAME/LINUX build/LINUX
ln -s ../../../../../../out $LA_UM_NAME/LINUX/android/out
ln -s ../../../../../../device $LA_UM_NAME/LINUX/android/device

ln -s ../$QCT_MPSS_NAME/modem_proc build/modem_proc
ln -s ../$MSM_DEVICE_DIR/common build/common
ln -s ../$MSM_DEVICE_DIR/contents.xml build/contents.xml
ln -s ../$QCT_RPM_NAME/rpm_proc build/rpm_proc
ln -s ../$QCT_VIDEO_NAME/venus_proc build/venus_proc

