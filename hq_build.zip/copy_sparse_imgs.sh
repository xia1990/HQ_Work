#!/bin/bash

# this script should run in ROOT_DIR/vendor/qcom/non-hlos
DEST_DIR=$1

NON_HLOS_DIR=`pwd`

if [ ! -d $DEST_DIR ]; then
    echo "mkdir -p $DEST_DIR"
    mkdir -p $DEST_DIR
fi

case $QCOM_PLATFORM in
    660)
        echo "cp -f ./$MSM_DEVICE_DIR/common/build/emmc/bin/asic/sparse_images/* $DEST_DIR"
        cp -f ./$MSM_DEVICE_DIR/common/build/emmc/bin/asic/sparse_images/* $DEST_DIR
        cp -f ./$MSM_DEVICE_DIR/common/build/emmc/patch0.xml $DEST_DIR
        ;;
    8917 | 8937 | 8953 |632 |sdm439 )
        echo "cp -f ./$MSM_DEVICE_DIR/common/build/bin/asic/sparse_images/* $DEST_DIR"
        cp -f ./$MSM_DEVICE_DIR/common/build/bin/asic/sparse_images/* $DEST_DIR
        cp -f ./$MSM_DEVICE_DIR/common/build/patch0.xml $DEST_DIR
        ;;
    *)
        echo "Error: Unsupported qcom platform=$platform!"
        exit 1
        ;;
esac

echo "copying sparse images is done!"
