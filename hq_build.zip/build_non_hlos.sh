#!/bin/bash

#参数一：device name (fire)
product_id=$1
build_mode=$2
#参数三:no_parse_cfg
arm_license=$3
#参数三：true/false 不加的话，默认为true
parse_cfg=$4

if [ x$parse_cfg = x"" ]; then
    parse_cfg=true
fi


if [[ x$product_id = x"" || x$build_mode = x"" || x$arm_license = x"" ]]; then
    echo "Error: Qproduct_id=$product_id build_mode=$build_mode arm_license=$arm_license"
    exit 1
fi

curr_dir=`pwd`
cd ../../../../
root_dir=`pwd`

if [ $parse_cfg = "true" ]; then
    source $root_dir/build/make/hq_tools/parse_config.sh
    parse_config $root_dir $product_id
    if [ $? != 0 ]; then echo "*** failed to parse configs! *** "; exit 1; fi
fi

cd $curr_dir
case $QCOM_PLATFORM in
    660)
      components="adsp cdsp modem tz"
      if [ x$arm_license = x"true" ]; then
        components=$components" boot rpm"
      fi
      ;;
    sm6150)
      components="adsp cdsp modem tz"
      if [ x$arm_license = x"true" ]; then
        components=$components" boot aop"
      fi
      ;;
    8917 | 8937 | 8953 | 632 | sdm439)
      components="adsp modem tz"
      if [ x$arm_license = x"true" ]; then
        components=$components" boot rpm"
      fi
      ;;
    *)
      echo "Error: Unsupported QCOM_PLATFORM=$QCOM_PLATFORM"
      exit 1 ;;
esac

echo "components=$components"

for cmpt in $components
do
    echo "./build_$cmpt.sh $product_id $build_mode no_parse_cfg"
    ./build_$cmpt.sh $product_id $build_mode no_parse_cfg

    if [ $? -gt 0 ]; then
        exit 1
    fi
done

