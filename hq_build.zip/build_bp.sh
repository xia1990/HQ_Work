#!/bin/bash
#编译bp侧脚本

function build_bp(){
	


}



########################3
build_bp

