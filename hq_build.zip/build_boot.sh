#!/bin/bash

# this script should execute in vendor/qcom/non-hlos/hq_build
product_id=$1
build_mode=$2
parse_cfg=$3
if [ x$parse_cfg = x"" ]; then
    parse_cfg=true
fi

if [ "$build_mode" = "" ]; then
    build_mode=remake
fi

# init dirs
curr_dir=`pwd`
cd ../../../../
root_dir=`pwd`

if [ $parse_cfg = "true" ]; then
    source $root_dir/build/make/hq_tools/parse_config.sh
    parse_config $root_dir $product_id
    if [ $? != 0 ]; then echo "*** failed to parse config! *** "; exit 1; fi
fi

if [ "${QCOM_PLATFORM}" = "sdm439" ];then
    qcom_target_family="8937"
else
    qcom_target_family="$QCOM_PLATFORM"
fi

export TOOLS_DIR=$root_dir/vendor/qcom/$NON_HLOS_DIR/qcom_tools
export LM_LICENSE_FILE=8224@192.168.128.247:8224@192.168.132.222

echo "==================== BUILD $QCT_BOOT_NAME START =================="
cd $root_dir/vendor/qcom/non-hlos/BOOT.XF.3.1/boot_images/QcomPkg/SDMPkg/6150
echo $(pwd)
#source setenv.sh
# Set up compiler path -- modified by HQ for license
export ARM_COMPILER_PATH=${TOOLS_DIR}/ARM_Compiler_5/bin64
export PYTHON_PATH=${TOOLS_DIR}/Python/Python-2.7.6
export MAKE_PATH=/usr/bin/make
export ARMTOOLS=ARMCT5.01
export ARMROOT=${TOOLS_DIR}/ARM_Compiler_5
export ARMLIB=$ARMROOT/lib
export ARMINCLUDE=$ARMROOT/include
export ARMINC=$ARMINCLUDE
export ARMBIN=$ARMROOT/bin64
export LLVMTOOLS=LLVM
export LLVMROOT=${TOOLS_DIR}/LLVM/4.0.2
export LLVMBIN=${TOOLS_DIR}/LLVM/4.0.2/bin
export LLVMLIB=$LLVMROOT/lib/clang/4.0.2/lib/linux
export LLVMINC=$MUSLPATH/include
export LLVM32INC=$MUSL32PATH/include
export LLVMTOOLPATH=$LLVMROOT/tools/bin
export PATH=$MAKE_PATH:$PYTHON_PATH:$ARM_COMPILER_PATH:$LLVMROOT:$PATH
export ARMHOME=$ARMROOT

case $build_mode in
    new) python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg,QcomToolsPkg --build_flags=cleanall
         python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg,QcomToolsPkg ;;
    remake) python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg,QcomToolsPkg ;;

    clean) python ../../buildex.py --variant LA -r RELEASE -t SDM6150Pkg,QcomToolsPkg --build_flags=cleanall ;;

esac

err=`grep "Build errors" build_boot.log`
if [[ $err != "" ]];then
    echo "==================== BUILD $QCT_BOOT_NAME FAIL =================="
    exit 1
else
    echo "==================== BUILD $QCT_BOOT_NAME COMPLETE =================="
fi

