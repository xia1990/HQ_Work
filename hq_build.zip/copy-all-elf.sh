#!/bin/bash

echo "========================== BEGIN TO COPY ELFS =========================="
#platform
qcom_platform=$1
if [[ "${qcom_platform}" != "8917" && \
      "${qcom_platform}" != "8953" && \
      "${qcom_platform}" != "450"  && \
      "${qcom_platform}" != "632"  && \
      "${qcom_platform}" != "sm6150"  && \
      "${qcom_platform}" != "sdm439" ]]
then
    echo "Unsupported QCOM TARGET_FAMILY=$1"
    exit 1
else
    echo "QCOM TARGET_FAMILY=${qcom_platform}"
fi

#components
if [ "$2" = "all" ]; then
    echo "copy_all_elf: HQ_BUILD_ARM_LICENSE=$HQ_BUILD_ARM_LICENSE"
    if [ "$HQ_BUILD_ARM_LICENSE" = "true" ]; then
        components="adsp modem tz boot rpm"
    else
        components="adsp modem tz"
    fi
else
    components=$2
fi

echo "copy components elf: $components"

#mkdir
# elf des dir should be out/target/product/${HQ_TARGET_DEVICE}/symbols
ELF_DES_DIR=$3
if [ "${ELF_DES_DIR}" == "" ] ; 
then
    echo "Invalid ELF_DES_DIR!"
    exit 1
fi

ELF_DES_DIR=${ELF_DES_DIR}'/non-hlos'

echo `pwd`



if [ "${qcom_platform}" = "8917" ]; then
adsp_files=(
$QCT_ADSP_NAME/adsp_proc/build/ms/*.elf
)

modem_files=(
$QCT_MPSS_NAME/modem_proc/build/ms/*.elf
)

boot_files=(
$QCT_BOOT_NAME/boot_images/core/bsp/bootloaders/sbl1/build/LAASANAZ/SBL1_ASIC.elf
)

rpm_files=(
$QCT_RPM_NAME/rpm_proc/core/bsp/rpm/build/8917/RPM_AAAAANAAR.elf
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/core/bsp/qsee/build/ZALAANAA/qsee.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/devcfg/build/ZALAANAA/devcfg.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/monitor/build/ZALAANAA/mon.elf
)


elif [ "${qcom_platform}" = "8953" ]; then
adsp_files=(
$QCT_ADSP_NAME/adsp_proc/build/ms/*.elf
)

modem_files=(
$QCT_MPSS_NAME/modem_proc/build/ms/*.elf
$QCT_MPSS_NAME/modem_proc/build/myps/qshrink/*.qsr4
)

boot_files=(
$QCT_BOOT_NAME/boot_images/core/bsp/bootloaders/sbl1/build/JAASANAZ/SBL1_ASIC.elf
)

rpm_files=(
$QCT_RPM_NAME/rpm_proc/core/bsp/rpm/build/8953/RPM_AAAAANAAR.elf
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/core/bsp/qsee/build/SANAANAA/qsee.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/devcfg/build/SANAANAA/devcfg.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/monitor/build/SANAANAA/mon.elf
)


elif [ "${qcom_platform}" = "632" ]; then
adsp_files=(
$QCT_ADSP_NAME/adsp_proc/build/ms/*.elf
)

modem_files=(
$QCT_MPSS_NAME/modem_proc/build/ms/*.elf
$QCT_MPSS_NAME/modem_proc/build/myps/qshrink/*.qsr4
)

boot_files=(
$QCT_BOOT_NAME/boot_images/core/bsp/bootloaders/sbl1/build/JAASANAZ/SBL1_ASIC.elf
)

rpm_files=(
$QCT_RPM_NAME/rpm_proc/core/bsp/rpm/build/8953/pm632/RPM_AAAAANAAR.elf
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/core/bsp/qsee/build/KAZAANAA/qsee.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/devcfg/build/KAZAANAA/devcfg.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/monitor/build/KAZAANAA/mon.elf
)

elif [ "${qcom_platform}" = "sdm439" ]; then
adsp_files=(
$QCT_ADSP_NAME/adsp_proc/build/ms/*.elf
$QCT_ADSP_NAME/adsp_proc/qdsp6/qshrink/src/msg_hash.txt
)

modem_files=(
$QCT_MPSS_NAME/modem_proc/build/ms/*.elf
$QCT_MPSS_NAME/modem_proc/build/myps/qshrink/msg_hash.txt
)

boot_files=(
$QCT_BOOT_NAME/boot_images/core/bsp/bootloaders/sbl1/build/FAASANAZ/SBL1_ASIC.elf
)

rpm_files=(
$QCT_RPM_NAME/rpm_proc/core/bsp/rpm/build/439/RPM_AAAAANAAR.elf
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/core/bsp/qsee/build/QAOAANAA/qsee.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/devcfg/build/QAOAANAA/devcfg.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/monitor/build/QAOAANAA/mon.elf
)

elif [ "${qcom_platform}" = "sm6150" ]; then
adsp_files=(
$QCT_ADSP_NAME/adsp_proc/build/ms/*.elf
$QCT_ADSP_NAME/adsp_proc/qdsp6/qshrink/src/msg_hash.txt
)

modem_files=(
$QCT_MPSS_NAME/modem_proc/build/ms/*.elf
$QCT_MPSS_NAME/modem_proc/build/myps/qshrink/msg_hash.txt
)

boot_files=(
$QCT_BOOT_NAME/boot_images/core/bsp/bootloaders/sbl1/build/FAASANAZ/SBL1_ASIC.elf
)

aop_files=(
$QCT_AOP_NAME/aop_proc/core/bsp/aop/build/7150/AOP_AAAAANAZO.elf
$QCT_AOP_NAME/aop_proc/core/bsp/aop/build/7150/AOP_AAAAANAZO_aop.elf
)

tz_files=(
$QCT_TZ_NAME/trustzone_images/core/bsp/qsee/build/QAOAANAA/qsee.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/devcfg/build/QAOAANAA/devcfg.elf
$QCT_TZ_NAME/trustzone_images/core/bsp/monitor/build/QAOAANAA/mon.elf
)

fi

#copy to des dir
for m in $components
do
    # mkdir if needed
    m_elf_des_dir=$ELF_DES_DIR"/$m"
    echo "des dir: $m_elf_des_dir"
    if [[ ! -e $m_elf_des_dir ]]; then
        echo "mkdir: $m_elf_des_dir"
        mkdir -p $m_elf_des_dir
        if [ $? != 0 ]; then exit 1; fi
    fi

    files=$m"_files[@]"
    for file in ${!files}
    do
        echo "Copy: $file"
        if [ -e $file ]; then
            cp  $file $m_elf_des_dir
        else
            echo "***FILE NO EXISTS*** $file"
        fi
    done
done
echo "========================== COPY ELFS COMPLETE =========================="

