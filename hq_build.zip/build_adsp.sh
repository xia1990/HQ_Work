#!/bin/bash
#编译modem

curr_dir=`pwd`
cd ../
root_dir=`pwd`
echo "--------------"
echo $root_dir
echo "--------------"

export TOOLS_DIR=$root_dir/qcom_tools
#UTLILS_ROOT=${TOOLS_DIR}/rvct22
BP_PATH=$root_dir

#============ 环境配置 ================
MAKE_PATH=/usr/bin
export HEXAGON_ROOT=$root_dir/qcom_tools/Hexagon_Tools
PYTHON_PATH=${TOOLS_DIR}/Python/Python-2.7.6
export PATH=${PYTHON_PATH}:${PATH}
#============ 环境配置 ================
cd -

function build_adsp(){
    echo "========== ADSP.VT.5.3 =========="
    if [ -d "$BP_PATH/ADSP.VT.5.3/adsp_proc" ]
    then
    cd "$BP_PATH/ADSP.VT.5.3/adsp_proc"
        python ./build/build.py -c sm6150 -o clean -f aDSP
        python ./build/build.py -c sm6150 -o all -f aDSP
        [ "${PIPESTATUS[0]}" != "0" ] && echo -e "\033[31mbuild ADSP.VT.5.3 error\033[0m" && exit 1
    cd -
    else
        echo -e "\033[31m$BP_PATH/TZ.BF.4.0.5/adsp_proc/build/ms/: no such file or directory!!! \033[0m"
        exit 1
    fi
}

===========
build_adsp
